import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../environments/environment';
import { AuthService } from '../services/auth.service';

export type ImageJobStatus = 'queued' | 'processing' | 'completed' | 'failed' | 'cancelling' | 'cancelled';
export interface ImageGenerationJob {
  id: string; status: ImageJobStatus; creation_id: string; generatedImage: string | null;
  model?: string | null; error_message?: string | null; credits_charged: number;
  created_at: string; started_at?: string | null; completed_at?: string | null;
}

@Injectable({ providedIn: 'root' })
export class ImageGenerationJobsService {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly base = `${environment.apiUrl}/api/image/jobs`;

  private async options() {
    const session = await this.auth.getSession();
    if (!session?.access_token) throw new Error('Sessione scaduta. Accedi di nuovo.');
    return { headers: new HttpHeaders({ Authorization: `Bearer ${session.access_token}` }) };
  }

  async createJob(payload: {
    prompt: string; negativePrompt?: string; aspectRatio?: string; sourceImage?: string;
    sourceImages?: string[]; subjectSource?: 'photo' | 'product' | 'invent';
    identityMode?: 'preserve' | 'reinterpret'; creationId?: string;
  }): Promise<{ jobId: string; status: ImageJobStatus; creationId: string }> {
    const r = await firstValueFrom(this.http.post<any>(this.base, payload, await this.options()));
    if (!r?.success || !r.jobId) throw new Error(r?.message || 'Impossibile avviare la generazione.');
    return { jobId: r.jobId, status: r.status, creationId: r.creationId };
  }

  async getJob(id: string): Promise<ImageGenerationJob> {
    const r = await firstValueFrom(this.http.get<any>(`${this.base}/${encodeURIComponent(id)}`, await this.options()));
    if (!r?.success || !r.job) throw new Error(r?.message || 'Job non trovato.');
    return r.job as ImageGenerationJob;
  }

  async listJobs(): Promise<ImageGenerationJob[]> {
    const r = await firstValueFrom(this.http.get<any>(this.base, await this.options()));
    if (!r?.success) throw new Error(r?.message || 'Impossibile recuperare le generazioni.');
    return r.jobs as ImageGenerationJob[];
  }

  async cancelJob(id: string): Promise<void> {
    await firstValueFrom(this.http.post(`${this.base}/${encodeURIComponent(id)}/cancel`, {}, await this.options()));
  }

  async waitForResult(id: string, onUpdate?: (job: ImageGenerationJob) => void, intervalMs = 2500): Promise<ImageGenerationJob> {
    while (true) {
      const job = await this.getJob(id);
      onUpdate?.(job);
      if (['completed', 'failed', 'cancelled'].includes(job.status)) return job;
      await new Promise(resolve => setTimeout(resolve, intervalMs));
    }
  }
}
